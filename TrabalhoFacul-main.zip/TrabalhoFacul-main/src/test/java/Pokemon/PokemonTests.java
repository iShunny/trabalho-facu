package Pokemon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.MerdaDeFacul.entity.Pokemon;

@SpringBootTest
public class PokemonTests {
	
	@Test
	public void criar() {
		//Pokemon p = new Pokemon(Long(long "1"), "abra");
		
	}
}
